<?php
session_start();
error_reporting(0);

if(isset($_SESSION["email"])){
	$email=$_SESSION["email"];
	 $conn=mysqli_connect('localhost','root','','project');

 	if(!$conn ) {
      die('Could not connect');
   }

	$sql = "SELECT name FROM equipment";


      
   $retval = mysqli_query( $conn, $sql );
   
   if(! $retval) {
      die('Could not enter data');
   }
   
  $i=0;
   while($row = mysqli_fetch_assoc($retval)){
    $arr[$i]=$row;
    $i++;
}


   mysqli_close($conn);

}else{
	header("Location:login.php");
}
?>

<!doctype html>
<html lang="en">
  <head>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
  <script type="text/javascript" src="js/popper.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <link href="css/style.css" rel="stylesheet">
  
    
  <title>account statement</title>
    
    <link href="css/signin.css" rel="stylesheet">
  </head>

  <body>
 <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
      <a class="navbar-brand" href="index.php">Kisan loan</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <?php
              if (isset($_SESSION["email"])) {
                echo '<a class="nav-link" href="profile.php">Profile</a>';
              }else{
                 echo '<a class="nav-link" href="login.php">Login</a>';
              }
            ?>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="team.php">Team</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="feedback.php">Feedback</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
        </ul>
       
      </div>
    </nav>




    <main role="main">

      <section class="jumbotron text-center">
        <div class="container">
          <h1 class="jumbotron-heading"><?php echo $_SESSION["name"];?></h1>
          <p class="lead text-muted">Welcome to your profile. Feel free to share your creativity.</p>
          <p>
            <a href="logout.php" class="btn btn-primary">Logout</a>
            <a href="items.php" class="btn btn-secondary">Items Having</a>
          </p>
        </div>
        <br><br>

        <center>
          
          <form action="account_script.php" method="post">

            <select name="item">
              <?php
                foreach ($arr as $prd) {
                  echo '<option value="'.$prd["name"].'">'.$prd["name"].'</option>';
                }
              ?>
            </select><br><br>
            <input type="date" name="date"><br><br>
            <input type="submit" value="submit">
          </form>

        </center>

      </section>

    </main>


  </body>
</html>
