<?php
session_start();
if(isset($_SESSION["email"])){
  header("Location:profile.php");
}
?>

<!doctype html>
<html lang="en">
  <head>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
  <script type="text/javascript" src="js/popper.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <link href="css/style.css" rel="stylesheet">
    
  <title>Login</title>
    
    <link href="css/signin.css" rel="stylesheet">

    <style type="text/css">
      body{
       margin-top: 100px;
      }

    </style>
  </head>

  <body>
  <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
      <a class="navbar-brand" href="index.php">kisan loan</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <?php
              if (isset($_SESSION["email"])) {
                echo '<a class="nav-link" href="profile.php">Profile</a>';
              }else{
                 echo '<a class="nav-link" href="login.php">Login</a>';
              }
            ?>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="customer.php">customer</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="feedback.php">Feedback</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
        </ul>
       
      </div>
    </nav>







    <div class="container">

      <form class="form-signin" action="auth.php" method="post">
        <h2 class="form-signin-heading">Please sign in</h2>
        <label for="inputEmail" class="sr-only">Email address</label>
        <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" name="pass" id="inputPassword" class="form-control" placeholder="Password" required>
      
        <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
        <br>
        <p>Don't have an account? <a href="signup.php">Signup here.</a></p>
      </form>


    </div> <!-- /container -->
  </body>
</html>
