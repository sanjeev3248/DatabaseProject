<?php
if(isset($_GET['email'])){
	$email = $_GET['email'];
	

	$conn = mysqli_connect('localhost','root','','project');

if(!$conn ) {
      die('Could not connect');
}

$sql = "DELETE FROM borrow WHERE email='$email'";
$retval = mysqli_query( $conn, $sql);

if(!$retval){
	die('cannot enter data');
}

mysqli_close($conn);

header('Location: equipment1.php');
}
?>