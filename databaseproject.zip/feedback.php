<?php
session_start();

?>

<!doctype html>
<html lang="en">
  <head>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
  <script type="text/javascript" src="js/popper.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <link href="css/style.css" rel="stylesheet">
  <link href="css/album.css" rel="stylesheet">
    
  <title>Feedback</title>

    
    <link href="css/signin.css" rel="stylesheet">
    <style type="text/css">
      body{
        margin-top: 100px;
      }
    </style>
  </head>

  <body>
  <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
      <a class="navbar-brand" href="index.php">kisan loan</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <?php
              if (isset($_SESSION["email"])) {
                echo '<a class="nav-link" href="profile.php">Profile</a>';
              }else{
                 echo '<a class="nav-link" href="login.php">Login</a>';
              }
            ?>
          </li>
          
          <li class="nav-item">
            <a class="nav-link" href="feedback.php">Feedback</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact Me</a>
          </li>
        </ul>
       
      </div>
    </nav>




    <div class="container">
    <center>
      <form enctype="multipart/form-data" method="post" action="_add_feedback.php">
      
      <input type="email" name="email" placeholder="email" required style="width:400px"><br><br>
      <input type="text" name="name" placeholder="name" required style="width:400px"><br><br>
      <textarea name="feedback" rows="10" cols="40" placeholder="type feedback..."></textarea><br>
      <input type="submit" value="Send Feedback">
    </form>
    </center>
    
      
    </div>


  </body>
</html>
