<?php
session_start();
$email=$_SESSION["email"];
if(isset($_GET["itm"]) && $email){

$item=$_GET["itm"];




$conn=mysqli_connect('localhost','root','','project');

 if(!$conn) {
      die('Could not connect');
   }

   $sqlq= "UPDATE equipment SET numavailable=numavailable+1 WHERE name='$item'";
   $retval = mysqli_query( $conn, $sqlq );
   
   if(!$retval) {
      die('Could not enter data');
   }

   $sql= "DELETE FROM borrow WHERE email='$email' AND equipname='$item'";
   $retval2 = mysqli_query( $conn, $sql );
   
   if(!$retval2) {
      die('Could not enter data');
   }

   
   mysqli_close($conn);

   header("Location: profile.php");
   die();
   }
   header("Location: profile.php");
   

?>