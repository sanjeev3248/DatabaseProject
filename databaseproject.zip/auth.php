<?php

if(isset($_POST["email"]) && isset($_POST["pass"])){

$email=$_POST["email"];
$pass=$_POST["pass"];
$conn=mysqli_connect('localhost','root','','project');

 if(!$conn ) {
      die('Could not connect');
   }
   
   $sql = "SELECT Name, password, email FROM signup WHERE email='$email'";


      
   $retval = mysqli_query( $conn, $sql );
   
   if(! $retval) {
      die('Could not enter data');
   }
  

   
  
 $row = mysqli_fetch_array($retval, MYSQLI_BOTH);

      $name=$row[0];
      $pass=$row[1];
      $email=$row[2];

   

if($_POST["email"]==$email && $_POST["pass"]==$pass){

session_start();
$_SESSION["email"] = $email;
$_SESSION["name"] = $name;
header("Location: profile.php");

}
elseif($_POST["email"]='guptavikrant123@gmail.com' && $_POST["pass"]='vikku123' ){
      header("Location:admin.php");
   }

else{
     header("Location:login.php");
die();
}
 mysqli_close($conn);}


?>