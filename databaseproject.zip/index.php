<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="js/popper.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	 <link href="css/cover.css" rel="stylesheet">


	 <style type="text/css">
	 	body{
	 		background: url(image/sa2.jpg);
      background-size: cover;
	 	}
	 </style>
</head>
<body>

<div class="site-wrapper">

      <div class="site-wrapper-inner">

        <div class="cover-container">

          <header class="masthead clearfix">
            <div class="inner">
              <h3 class="masthead-brand">kisan loan</h3>
              <nav class="nav nav-masthead">
                <a class="nav-link active" href="index.php">Home</a>
                <?php
              if (isset($_SESSION["email"])) {
                echo '<a class="nav-link" href="profile.php">Profile</a>';
              }else{
                 echo '<a class="nav-link" href="login.php">Login</a>';
              }
            ?>
              </nav>
            </div>
          </header>

          <main role="main" class="inner cover">
            <h1 class="cover-heading">Welcome to Kisan Loan.</h1>
            <p class="lead">Click the button below to explore.</p>
            <p class="lead">
              <a href="login.php" class="btn btn-lg btn-secondary">Start</a>
            </p>
          </main>

          <footer class="mastfoot">
            <div class="inner">
              <p>Created by Sanjeev.</p>
            </div>
          </footer>

        </div>

      </div>

    </div>



</body>
</html>