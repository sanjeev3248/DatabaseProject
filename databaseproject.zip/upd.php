<?php
session_start();
if(isset($_GET['id']) && isset($_GET['val'])){

	 $conn=mysqli_connect('localhost','root','','project');
	 $email=$_SESSION["email"];
  if(!$conn ) {
      die('Could not connect');
   }
   $id = $_GET['id'];
   $val=$_GET['val'];
  $sql = "INSERT INTO repayment VALUES('$id','$email','$val')";
  $sql2 = "UPDATE loan SET amt=amt-'$val'";


   $retval = mysqli_query( $conn, $sql );
   $retval2= mysqli_query( $conn, $sql2 );
   
   if(! $retval) {
      die('Could not enter data');
   }
}

header("Location:profile.php");

?>