<?php


if(isset($_POST["emailid"]) && isset($_POST["name"]) && isset($_POST["phone"]) && isset($_POST["age"]) && isset($_POST["pass"]) && isset($_POST["cpass"])){

$email=$_POST["emailid"];
$name=$_POST["name"];
$phone=$_POST["phone"];
$age=$_POST["age"];
$pass=$_POST["pass"];
$cpass=$_POST["cpass"];


if($pass!=$cpass){

header("Location: signup.php");

}else{

$conn=mysqli_connect('localhost','root','','project');

 if(!$conn) {
      die('Could not connect');
   }
   
   $sql = "INSERT INTO signup VALUES ('$email','$name','$age','$phone','$pass')";



   $retval = mysqli_query( $conn, $sql );
   
   if(!$retval) {
      die('Could not enter data');
   }
   
  
   
   mysqli_close($conn);

   header("Location: login.php");
   die();
   }}
   header("Location: login.php");

?>