<?php
session_start();
//error_reporting(0);

if(isset($_SESSION["email"])){
	$email=$_SESSION["email"];
	 $conn=mysqli_connect('localhost','root','','project');

 	if(!$conn ) {
      die('Could not connect');
   }

   if(isset($_POST['loan_type']) && isset($_POST['amt']) && isset($_POST['mon'])){

      $id = hash("adler32",$email.time());
      $lt = $_POST['loan_type'];
      $amt = $_POST['amt'];
      $mon = $_POST['mon'];
  $sql = "INSERT INTO loan VALUES('$id', '$email', '$lt' , '$amt', '$mon')";

   $retval = mysqli_query( $conn, $sql );
   
   if(! $retval) {
      die('Could not enter data');
   }

   }



   mysqli_close($conn);

}else{
	header("Location:login.php");
}
?>

<!doctype html>
<html lang="en">
  <head>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
  <script type="text/javascript" src="js/popper.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <link href="css/style.css" rel="stylesheet">
  
    
  <title>Take Loan</title>
    
    <link href="css/signin.css" rel="stylesheet">
  </head>

  <body>
 <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
      <a class="navbar-brand" href="index.php">kisan loan</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <?php
              if (isset($_SESSION["email"])) {
                echo '<a class="nav-link" href="profile.php">Profile</a>';
              }else{
                 echo '<a class="nav-link" href="login.php">Login</a>';
              }
            ?>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="feedback.php">Feedback</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact Me</a>
          </li>
        </ul>
       
      </div>
    </nav>




    <main role="main">

      <section class="jumbotron text-center">
        <div class="container">
          <h1 class="jumbotron-heading"><?php echo $_SESSION["name"];?></h1>
          <p class="lead text-muted">Welcome to your profile. Feel free to share your creativity.</p>
          <p>
            <a href="logout.php" class="btn btn-primary">Logout</a>
          </p>
        </div>
        <br><br>

        <center>
          <ul class="list-group" style="width: 700px">
            <a href="take_loan.php"><li class="list-group-item">Take Loan</li></a>
            <a href="details.php"><li class="list-group-item">EMI Payment Details</li></a>
            <a href="loans.php"><li class="list-group-item">pending</li></a>
          
        </ul>
            </center>

            <br><br>

            <form action="take_loan.php" method="POST">
             Select Loan type: <select name="loan_type"><option value="summer">Summer Loan</option><option value="winter">Winter Loan</option></select><br><br>
             Select amount: <input type="number" name="amt"><br><br>
             Input duration (in months) :<input type="number" name="mon"><br><br>
             <input type="submit" value="submit">

            </form>

      </section>

    </main>


  </body>
</html>
