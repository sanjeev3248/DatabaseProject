<?php
session_start();

if(isset($_POST["email"]) && isset($_POST["name"]) && isset($_POST["feedback"])){

$email=$_POST["email"];
$name=$_POST["name"];
$fb=$_POST["feedback"];



$conn=mysqli_connect('localhost','root','','project');

 if(!$conn) {
      die('Could not connect');
   }
   
   $sql = "INSERT INTO feedback VALUES ('$email','$name','$fb')";


   $retval = mysqli_query( $conn, $sql );
   
   if(!$retval) {
      die('Could not enter data');
   }
   
  
   
   mysqli_close($conn);

   header("Location: index.php");
   die();
   }
   header("Location: index.php");

?>