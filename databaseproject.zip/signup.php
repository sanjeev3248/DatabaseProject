<?php
session_start();
if(isset($_SESSION["email"])){
  header("Location:profile.php");
}
?>
<!doctype html>
<html lang="en">
  <head>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
  <script type="text/javascript" src="js/popper.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <link href="css/style.css" rel="stylesheet">
    
  <title>Signup</title>
    
    <link href="css/signin.css" rel="stylesheet">
    <style type="text/css">
      body{
       margin-top: 100px;
      }
    </style>
  </head>

  <body>
  <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
      <a class="navbar-brand" href="index.php">kisan loan</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <?php
              if (isset($_SESSION["email"])) {
                echo '<a class="nav-link" href="profile.php">Profile</a>';
              }else{
                 echo '<a class="nav-link" href="login.php">Login</a>';
              }
            ?>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="customer.php">customer</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="feedback.php">Feedback</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact Me </a>
          </li>
        </ul>
       
      </div>
    </nav>






    <div class="container">

      <form class="form-signin" action="register.php" method="post">
        <h2 class="form-signin-heading">Please Sign Up</h2>
        <input type="email" name="emailid" class="form-control" placeholder="Email address" required autofocus>
        <input type="text" name="name" class="form-control" placeholder="Name" required>
        <input type="number" name="phone" class="form-control" placeholder="Phone" required>
        <input type="number" name="age" class="form-control" placeholder="Age" required>
        <input type="password" name="pass" class="form-control" placeholder="Password" required style="margin-bottom:0px">
        <input type="password" name="cpass" class="form-control" placeholder="Confirm Password" required>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Sign up</button>
        <br>
        <p>Already have an account? <a href="login.php">Signin here.</a></p>
      </form>


    </div> <!-- /container -->
  </body>
</html>
