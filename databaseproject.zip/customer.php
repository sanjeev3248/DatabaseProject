
_<?php
error_reporting(0);
$conn=mysqli_connect('localhost','root','','project');

if(!$conn ) {
      die('Could not connect');
   }
   
   $sql = 'SELECT * FROM playerteam';
   $retval = mysqli_query( $conn, $sql );
   if(! $retval) {
      die('Could not fetch data');
   }

 mysqli_close($conn);
   


?>

<!DOCTYPE html>
<html>
<head>
<title>DISPLAY_EQUIPMENT</title>

 <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
  <script type="text/javascript" src="js/popper.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <link href="css/style.css" rel="stylesheet">
    
   
 <style>
#customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 60%;
}

#customers td, #customers th {
    border: 1px solid #fff;
    padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: rgb(120, 204, 183);}

#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: rgb(64, 114, 102);
    color: white;
}






body {
    background-image: url("image/3.jpg");
    background-repeat: no-repeat;
    background-size: cover;
}
</style>
</head>
<body>
<center>
  <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
      <a class="navbar-brand" href="index.php">kisan loan</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <?php
              if (isset($_SESSION["email"])) {
                echo '<a class="nav-link" href="profile.php">Profile</a>';
              }else{
                 echo '<a class="nav-link" href="login.php">Logout</a>';
              }
            ?>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="team.php">Team</a>
          </li>
          
        </ul>
       
      </div>
    </nav>

<br/>
<br/>
<br/>


    

<h1>PLAYER_DETIALS</h1>
 
<br/>
</br>
<table id="customers">
  
<tbody>
  
<th>username</th>
<th>teamname</th>
<th>playertype</th>
</tbody>

<?php ; while($row=mysqli_fetch_array($retval)) {; ?>
<tr>
<td><?php echo $row['username']; ?></td> 
<td><?php echo $row['teamname']; ?></td>
<td><?php echo $row['playertype']; ?></td>

</tr>
<?php } ?>
</tbody>

</table>
</center>
  
 

</body>
</html>